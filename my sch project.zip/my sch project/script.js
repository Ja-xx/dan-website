function displayFileName() {
    Var fileInput = document.getElementById('file-upload');
    Var fileNameDisplay = document.getElementById('file-name');

    If (fileInput.files.length > 0) {
        fileNameDisplay.innerText = "Selected File: " + fileInput.files[0].name;
    } 
       else {
        fileNameDisplay.innerText = "";
    }
}
